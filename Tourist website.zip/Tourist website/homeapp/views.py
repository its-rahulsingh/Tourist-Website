from multiprocessing import context
import numbers
from django.http import HttpResponse
from django.shortcuts import render, HttpResponse,redirect
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from datetime import datetime
from homeapp.models import Contact,Signup

# Create your views here.

def index(request):
    context={"variable":"this is variable"}
    return render(request,'index.html',context)
    # return HttpResponse("Hello in world")
def about(request):
    return render(request,'about.html')
def home(request):
    return render(request,'index.html')
    # return HttpResponse("Hello in about")
def services(request):
    return render(request,'services.html')
    # return HttpResponse("Hello in services")
def contact(request):
    if request.method=='POST':
        name= request.POST.get('fname')
        email= request.POST.get('email')
        number= request.POST.get('number')
        reason= request.POST.get('reason')
        print(name,email,number,reason)
        date=datetime.today()
        contact=Contact(name=name,email=email,number=number,reason=reason,date=datetime)
        contact.save()

    return render(request,'contact.html')
    # return HttpResponse("Hello in contact")

def login(request):
    if request.method=='POST':
        name= request.POST.get('username')
        email= request.POST.get('password')
        user=authenticate(username=name,password=email)
        if user is not None:
            print(user)
            auth_login(request,user)
            messages.success(request,'Logged in successfully')
            return render(request,'index.html')
        else:
            messages.success(request,'Invalid Credentials, Please try again')
            return redirect('login')


    return render(request,'login.html')

def signup(request):
    if request.method=='POST':
        name= request.POST.get('fname')
        email= request.POST.get('email')
        password= request.POST.get('password')
        date=datetime.today()
        print(name,email,password,date)
        # signup=Signup(name=name,email=email,password=password,date=date)
        # signup.save()
        # task=Signup.objects.all()
        # m={'ram':task}
        # for item in task:
        #     print(item.email)
        # print(m)
        myuser=User.objects.create_user(name,email,password)
        myuser.save()
        messages.success(request,"ID created successfully")
        return redirect('login')
    return render(request,'signup.html')

def logout(request):
    auth_logout(request)
    messages.success(request,"Successfully logged out")
    return redirect('home')
