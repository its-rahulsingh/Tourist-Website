import email
from msilib.schema import Class
from django.db import models

# Create your models here.
class Contact(models.Model):
    name=models.CharField(max_length=122)
    email=models.CharField(max_length=122)
    number=models.CharField(max_length=122)
    reason=models.TextField()

    def __str__(self):
        return self.name

class Signup(models.Model):
    name=models.CharField(max_length=122)
    email=models.CharField(max_length=122)
    password=models.CharField(max_length=122)
    date=models.CharField(max_length=122)
    

    def __str__(self):
        return self.name

