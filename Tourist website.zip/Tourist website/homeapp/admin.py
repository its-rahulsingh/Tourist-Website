from django.contrib import admin

# from homeapp.models import Contact
from homeapp.models import Contact,Signup

# Register your models here.
admin.site.register(Contact)
admin.site.register(Signup)
